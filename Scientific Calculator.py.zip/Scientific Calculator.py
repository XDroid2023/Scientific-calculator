# Sientific calculator

import math

class ScientificCalculator:

    def add(self, x, y):
        return x + y

    def subtract(self, x, y):
        return x - y

    def multiply(self, x, y):
        return x * y

    def divide(self, x, y):
        if y == 0:
            raise ValueError("Cannot divide by zero!")
        return x/ y
    
    def power(self, base, exponent):
        return base ** exponent

    def sqrt(self, x):
        if x < 0:
            raise ValueError("Cannot take the square root of a negative number!")
        return math.sqrt(x)

    def sine(self, theta):
        return math.sin(math.radians(theta))

    def cosine(self, theta):
        return math.cos(math.radians(theta))

    def tangent(self, theta):
        return math.tan(math.radians(theta))

    def log(self, x, base=math.e):
        if x <= 0:
            raise ValueError("Log not defined for non-positive values")
        return math.log(x, base)
    

        



               
